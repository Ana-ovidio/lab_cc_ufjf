init();

function init() {

    // As seguintes variáveis são definidas no escopo global
    var num1 = 20,
        num2 = 3,
        nome = "JavaScript !"; 


    // Um exemplo de função aninhada
    function getScore() {
        var num1 = Number(prompt('Entre com num1'));
        var num2 = Number(prompt('Entre com num2'));
        resto_divisao = num1%2;
      
        function add() {
            soma = num1 + num2;
            return nome + " com um total de: " + soma;
        }
      
        function multiplicacao_valor() {
          mult = (resto_divisao != 0 ? (num1*5) : num1)
          return nome + "Multiplicação será: " + mult;
        }
        
        return multiplicacao_valor();
    }

    document.getElementById("saida").innerHTML = getScore(); // Retorna o valor ao HTML
}
