init();

function init() {

    // As seguintes variáveis são definidas no escopo global
    var num1 = 20,
        num2 = 3,
        nome = "JavaScript !"; 


    // Um exemplo de função aninhada
    function getScore() {
        var num1 = Number(prompt('Entre com num1'));
        var num2 = Number(prompt('Entre com num2'));
        resto_divisao = num1%2;
      
        function add() {
          soma = num1 + num2;
          return "Adição: " + soma;
        }
      
        function multiplicacao_valor() {
            mult = num1*num2;
            return "Multiplicação: " + mult;
        }
      
        function sub() {
          sub = num1-num2;
          return "Subtração: " + sub;
        }
      
        function div() {
          div = (num1/num2)
          return "Divisão: " + ;
        }
        
        return add() + " " + multiplicacao_valor() + " " + div + " " + sub + " ";
    }

    document.getElementById("saida").innerHTML = getScore(); // Retorna o valor ao HTML
}
